#ifndef CODE_H
#define CODE_H

// Функция фильтрующая(сглаживающая) значения берет старое с меньшим весом и новое с большим
float filtr_My(float old_, float new_, float ves_new_)
{
  return (old_ * (1.0 - ves_new_)) + (new_ * ves_new_);
}

// // Задача для нулевого ядра
// TaskHandle_t TaskCore0;

// void loop_0_core(void *pvParameters)
// {
//     for (;;) // Бесконечный цикл. По while(1) не работает из-за сторожевого таймера
//     {
//         // digitalWrite(led1, HIGH);
//         // delay(1000);
//         // digitalWrite(led1, LOW);
//         // delay(1000);
//         // Serial.print("Task0code running on core = ");
//         // Serial.println(xPortGetCoreID());
//     }
//     //vTaskDelete(TaskCore0); // Удаление ранее созданной задачи
// }
// // Создаем задачу с кодом из функции Task1code(), с приоритетом 1 и выполняемую на ядре 0:
// void useCore0()
// {
//     xTaskCreatePinnedToCore(
//         loop_0_core, /* Функция задачи */
//         "TaskCore0", /* Название задачи */
//         10000,       /* Размер стека задачи */
//         NULL,        /* Параметр задачи */
//         1,           /* Приоритет задачи */
//         &TaskCore0,  /* Идентификатор задачи, чтобы ее можно было отслеживать */
//         0);          /* Ядро для выполнения задачи (0) */
//     delay(500);
// }

void initLed()
{
  pinMode(PIN_LED_RED, OUTPUT);  //Не работает пин. При инициализации SPI_slave функция его занимает и дает всегда половину напряжения и он не реагирует на команды.
  pinMode(PIN_LED_BLUE, OUTPUT);
  digitalWrite(PIN_LED_RED, 1);   // Запустился SetUp
  digitalWrite(PIN_LED_BLUE, 1); // Запустился SetUp
}

void offLed()
{
  digitalWrite(PIN_LED_RED, 0);   // Запустился SetUp
  digitalWrite(PIN_LED_BLUE, 0); // Запустился SetUp
}
//Функция мигания светодиодом в основном цикле
void Led_Blink(int led_, unsigned long time_)
{
  static unsigned long led_time = 0;
  static bool led_status = 0;
  if ((millis() - led_time) > time_)
  {
    led_status = 1 - led_status;
    digitalWrite(led_, led_status);
    // digitalWrite(PIN_POWER_OFF, 1); // Выключение питания
    // delay(50);
    // digitalWrite(PIN_POWER_OFF, 0); // Выключение питания
    led_time = millis();
  }
}

// Функция сканирования I2C устройств
void scanI2C()
{
  byte error, address;
  int nDevices;

  Serial.println("Scanning...");

  nDevices = 0;
  for (address = 8; address < 127; address++)
  {
    Wire.beginTransmission(address);
    error = Wire.endTransmission();

    if (error == 0)
    {
      Serial.print("I2C device found at address 0x");
      if (address < 16)
        Serial.print("0");
      Serial.print(address, HEX);
      Serial.println(" !");

      nDevices++;
    }
    else if (error == 4)
    {
      Serial.print("Unknow error at address 0x");
      if (address < 16)
        Serial.print("0");
      Serial.println(address, HEX);
    }
  }
  if (nDevices == 0)
    Serial.println("No I2C devices found\n");
  else
    Serial.println("done\n");
}

// задаем свойства ШИМ-сигнала:
const int freq = 5000;
const int ledChannel = 0;
const int resolution = 8; // 8 бит от 0 до 255,  10 бит от 0 до 1024

void initPWM()
{
  // // настраиваем ШИМ-сигнал, используя свойства выше:
  // ledcSetup(ledChannel, freq, resolution);
  // // привязываем ШИМ канал к GPIO-контакту, которым будем управлять:
  // ledcAttachPin(led2, ledChannel);
}

//Управление ярокстью светодиода меняя ШИМ
void ledPWM()
{
  // увеличиваем яркость светодиода:
  for (int dutyCycle = 0; dutyCycle <= 255; dutyCycle++)
  {
    // меняем яркость светодиода при помощи ШИМ:
    ledcWrite(ledChannel, dutyCycle);
    delay(15);
  }

  // уменьшаем яркость светодиода:
  for (int dutyCycle = 255; dutyCycle >= 0; dutyCycle--)
  {
    // меняем яркость светодиода при помощи ШИМ:
    ledcWrite(ledChannel, dutyCycle);
    delay(15);
  }
}



// Отработка пришедших команд. Изменение скорости, траектории и прочее
void executeCommand()
{
  static int command_pred = 0;                                                               // Переменная для запоминания предыдущей команды
  if (Data2Body_receive.command_body == 0 && Data2Body_receive.command_body != command_pred) // Если пришла команда 0 и предыдущая была другая
  {
    //Serial.println("commanda  STOP...");
    stopMotor(); //все останавливаем
  }
  if (Data2Body_receive.command_body == 1) // Если командв двигаться то азадем движение на 1 секунду
  {
    setSpeed_time(Data2Body_receive.speed, Data2Body_receive.radius, 1000);
    //setSpeed_time(0.2, 0.2, 1000);
  }
  command_pred = Data2Body_receive.command_body; // Запоминаяем команду

  setServoMotorVideoAngle(Data2Body_receive.motor_video_angle);  // Установка в нужное число градусов видеокамеры
}

uint32_t Read_VL53L0X(VL53L0X &sensor_, uint8_t num_line_)
{
  set_TCA9548A(num_line_); // Переключаем мультиплексор
  uint32_t rez = 0;
  //float rez = sensor.readRangeContinuousMillimeters();
  if ((sensor_.readReg(0x13) & 0x07) != 0)
  {
    rez = sensor_.readReg16Bit(0x1E);
    sensor_.writeReg(0x0B, 0x01);
  }
  else
  {
    Serial.print("-01/");
    Serial.println(-num_line_);
  }
  return rez;
}

void Init_VL53L0X(VL53L0X &sensor_, uint8_t num_line_)
{
  Serial.println("-------------------------------------------------------------");
  Serial.print("Start Init_VL53L0X... Line =  ");
  Serial.println(num_line_);

  set_TCA9548A(num_line_);  // Переключаем мультиплексор
  sensor_.setTimeout(1000); // Время на выполения функций конфигурации если превышено выдает ошибку
  byte address = sensor_.readReg(0x8A);
  Serial.print(" address = ");
  Serial.print(address, HEX);
  byte WiA = sensor_.readReg(0xC0);
  Serial.print(" WiA = ");
  Serial.println(WiA);

  if (sensor_.init())
  {
    Serial.println("Init_VL53L0X OK !!!");
    // Start continuous back-to-back mode (take readings as	 fast as possible).  To use continuous timed mode  instead, provide a desired inter-measurement period in  ms (e.g. sensor.startContinuous(100)).
    sensor_.startContinuous();
    sensor_.setMeasurementTimingBudget(25000);
  }
  else
  {
    Serial.println(" !!!!!!!!!!!!!!!!!!Failed to detect and initialize sensor!");
    delay(5000);
  }
  Serial.println("End Init_VL53L0X ===");
}

void loop_VL53L0X()
{

  float lazer_L_temp = Read_VL53L0X(Sensor_VL53L0X_L, multi_line_VL53L0X_L) / 1000.0; // Преобразуем в метры
  float lazer_R_temp = Read_VL53L0X(Sensor_VL53L0X_R, multi_line_VL53L0X_R) / 1000.0; // Преобразуем в метры

  // lazer_L = (lazer_L_temp * 0.66) + (lazer_L * 0.34); // Небольшое сглаживание с прошлым результатом Можно отфильтровать Калманом если нужно
  // lazer_R = (lazer_R_temp * 0.66) + (lazer_R * 0.34); // Небольшое сглаживание с прошлым результатом Можно отфильтровать Калманом если нужно

  lazer_L = filtr_My(lazer_L, lazer_L_temp, 0.67);
  lazer_R = filtr_My(lazer_R, lazer_R_temp, 0.67);

  //Ограничение в 1 метр
  if (lazer_L > 1)
    lazer_L = 1;
  if (lazer_R > 1)
    lazer_R = 1;

  // Serial.print(" Sensor_VL53L0X_L = ");
  // Serial.print(lazer_L);
  // Serial.print(" Sensor_VL53L0X_R = ");
  // Serial.print(lazer_R);
  // Serial.println("");

  // float dist_laz = Read_VL53L0X() ; // Превобразуем в метры
}


//Функция возвращает напряжение которое подается на аналоговый пин через делитель с датчиков газа. Они питаются от 5 вольт
float getVoltAnalogPin(int pin_)
{
  //analogReadResolution(12);  // Установка разрешния на аналоговых входах
  // uint32_t a = micros();
  // float aa = analogRead(pin_);
  // uint32_t b = micros();
  // Serial.print("t= ");
  // Serial.println(b-a);
  return analogRead(pin_) * (5 / 4095.0) + 0.3; // Примерно врут на 0,3 вольта, поэтому прибавляю
}

//Функция исполняемая по прерыванию по таймеру 0
void IRAM_ATTR onTimer() // Обработчик прерывания таймера 0 по совпадению A 	1 раз в 1 милисекунду
{
  //portENTER_CRITICAL_ISR(&timerMux);
  //interruptCounter++;
  //portEXIT_CRITICAL_ISR(&timerMux);

  count_timer_10millisec++;
  count_timer_50millisec++;
  count_timer_1sec++;
  count_timer_60sec++;

  // каждые 10 милисекунд
  if (count_timer_10millisec >= 10)
  {
    count_timer_10millisec = 0;
    flag_timer_10millisec = true;
  }
  // каждые 50 милисекунд
  if (count_timer_50millisec >= 50)
  {
    count_timer_50millisec = 0;
    flag_timer_50millisec = true;
  }
  // 1 seconds
  if (count_timer_1sec >= 1000)
  {
    count_timer_1sec = 0;
    flag_timer_1sec = true;
  }
  // Таймер на 1 минуту
  if (count_timer_60sec >= 60000)
  {
    count_timer_60sec = 0;
    flag_timer_60sec = true;
  }
}

//Инициализация таймера 0. Всего 4 таймера вроде от 0 до 3 //https://techtutorialsx.com/2017/10/07/esp32-arduino-timer-interrupts/
void initTimer_0()
{
  timer0 = timerBegin(0, 80, true);             // Номер таймера, делитель(прескаллер), Считать вверх, прибавлять (true)  Частота базового сигнала 80  Мега герц, значит будет 1 микросекунда
  timerAttachInterrupt(timer0, &onTimer, true); // Какой таймер используем, какую функцию вызываем,  тип прерывания  edge или level interrupts
  timerAlarmWrite(timer0, 1000, true);          // Какой таймер, до скольки считаем , сбрасываем ли счетчик при срабатывании 1000 микросекунд эти 1 милисекунда
  timerAlarmEnable(timer0);                     // Запускаем таймер
}

// Начальная инициализация датчика
void init_INA219()
{
  set_TCA9548A(multi_line_INA219); //Переключаем мультиплексор
  // Initialize the INA219.
  // By default the initialization will use the largest range (32V, 2A).  However
  // you can call a setCalibration function to change this range (see comments).
  if (!Ina219.begin())
  {
    Serial.println("Failed to find INA219 chip");
    while (1)
    {
      delay(10);
    }
  }
  // To use a slightly lower 32V, 1A range (higher precision on amps):
  //Ina219.setCalibration_32V_2A();
  // To use a slightly lower 16V, 5A range (higher precision on amps):
  Ina219.setCalibration_16V_5A();

  Serial.println("Measuring voltage and current with INA219 ...");

  Serial.println("Read value Power from memory ...");
  Ina219.readValue(); // Считывание значений при запуске
}

unsigned long deltaTest = 0;
void test(uint32_t count)
{

    double dq = 180 / count;
    double q = 1;
    double sum = 0;

    unsigned long start = micros();

    for (uint32_t i = 0; i < count; i++)
    {
        sum += sin(q);
        sum += cos(q);
        sum += tan(q);
        q += dq;
    }
    unsigned long finish = micros();
    deltaTest = finish - start;

    Serial.print( " Count=");
    Serial.print( count);
    Serial.print( " Sum=");
    Serial.print( sum);
    Serial.print( " Start=");
    Serial.print( start);
    Serial.print( " Finish=");
    Serial.print( finish);
    Serial.print( " delta=");
    Serial.println( deltaTest);
}

// Собираем нужные данные и пишем в структуру на отправку
void collect_Data()
{
    Body_send.id++;
    Body_send.odom_enc = g_odom_enc;
    Body_send.odom_imu = g_odom_imu;
    Body_send.odom_L = odom_way_L;
    Body_send.odom_R = odom_way_R;
    Body_send.speed_L = speed_L_fact;
    Body_send.speed_R = speed_R_fact;
    Body_send.distance_lazer_L = lazer_L;
    Body_send.distance_lazer_R = lazer_R;
    Body_send.distance_uzi = distance_uzi;
    Body_send.bno055.roll = BNO055_EulerAngles.x;
    Body_send.bno055.pitch = BNO055_EulerAngles.y;
    Body_send.bno055.yaw = BNO055_EulerAngles.z;
    Body_send.bme.temperature = bme680.temperature;
    Body_send.bme.pressure = bme680.pressure / 100.0;
    Body_send.bme.humidity = bme680.humidity;
    Body_send.bme.loc = bme680.gas_resistance/ 1000.0;
    Body_send.ina.voltage = Ina219.inVoltage;
    Body_send.ina.current = Ina219.current_mA / 1000.0; // В амперах передаем
    Body_send.ina.capacity_percent = Ina219.capacity_percent;
    Body_send.ina.capacity_real = Ina219.capacity_real;
    Body_send.gaz_data = filtr_My(Body_send.gaz_data, gaz_volt, 0.67); // Небольшое сглаживание показаний
    Body_send.lux = g_lux;     // Значение освещенности

    Body_send.cheksum = measureCheksum(Body_send); // Вычисляем контрольную сумму структуры и пишем ее значение в последний элемент

    //Serial.println("");
}
void printBody()
{

    printf(" id= %i \n", Body_send.id);
    printf(" odom_L= %f \n", Body_send.odom_L);
    printf(" odom_R= %f \n", Body_send.odom_R);
    printf(" speed_L= %f \n", Body_send.speed_L);
    printf(" speed_R= %f \n", Body_send.speed_R);
    printf(" distance_lazer_L= %f \n", Body_send.distance_lazer_L);
    printf(" distance_lazer_R= %f \n", Body_send.distance_lazer_R);
    printf(" distance_uzi= %f \n", Body_send.distance_uzi);
    printf(" roll= %f \n", Body_send.bno055.roll);
    printf(" pitch= %f \n", Body_send.bno055.pitch);
    printf(" yaw= %f \n", Body_send.bno055.yaw);
    printf(" temperature= %f \n", Body_send.bme.temperature);
    printf(" pressure= %f \n", Body_send.bme.pressure);
    printf(" humidity= %f \n", Body_send.bme.humidity);
    printf(" loc= %f \n", Body_send.bme.loc);
    printf(" voltage= %f \n", Body_send.ina.voltage);
    printf(" current= %f \n", Body_send.ina.current);
    printf(" capacity_percent= %f \n", Body_send.ina.capacity_percent);
    printf(" capacity_real= %f \n", Body_send.ina.capacity_real);
    printf(" gaz_volt= %f \n", gaz_volt);
    printf(" gaz_data= %f \n", Body_send.gaz_data);
    printf(" lux = %f \n", Body_send.lux);
    printf(" Send cheksum= %i  \n --- \n", Body_send.cheksum);
}

#endif