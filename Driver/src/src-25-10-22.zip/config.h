#ifndef CONFIG_H
#define CONFIG_H

// Контакты для светодиодов:
const int PIN_LED_RED = 4; //Для красного светодиода перепаял
//Нельзя использовать нулевой пин Не работает пин. При инициализации SPI_slave функция его занимает и дает всегда половину напряжения и он не реагирует на команды.
const int PIN_LED_BLUE = 15;
const int PIN_ANALIZ = 13;

const int PIN_GAZ = 36; // Пин на который подключен датчик газа аналоговый
float gaz_volt = 0; // Значение напряжения на аналоговом пине с датчика газа



#define multi_line_BNO 0       // На какой линии мультиплексора находится датчик BNO055
#define multi_line_VL53L0X_L 7 // На какой линии мультиплексора находится датчик VL53L0X
#define multi_line_VL53L0X_R 6 // На какой линии мультиплексора находится датчик VL53L0X
#define multi_line_BME 1       // На какой линии мультиплексора находится датчик BMP280



uint64_t time_izmerenia = 0;      // Время в которое считываем данные из датчика
float delta_time_izmerenia = 0;   // Время между измерениями. передаем в ПИД регуляторы для расчетов
uint64_t pred_time_izmerenia = 0; // Предыдущее время измерения.

volatile bool flag_timer_1sec = false;
volatile bool flag_timer_10millisec = false;
volatile bool flag_timer_50millisec = false;
volatile bool flag_timer_60sec = false;
volatile int count_timer_10millisec = 0; //Счетчик для запуска обработки движения моторов в лупе по флагу
volatile int count_timer_50millisec = 0; //Счетчик для запуска каждые 50 милисекунд
volatile int count_timer_1sec = 0;       // Счетчик для запуска
volatile int count_timer_60sec = 0;      // Счетчик для запуска

hw_timer_t *timer0 = NULL;
hw_timer_t *timer1 = NULL;
hw_timer_t *timer2 = NULL;
hw_timer_t *timer3 = NULL;

float lazer_L = 0; // Данные с датчиков лазерных левого и правого
float lazer_R = 0; // Данные с датчиков лазерных левого и правого

//*********************************************************************
//Структура для углов наклонов
struct Struct_RPY
{
  float roll = 0;  // Крен в право  влево
  float pitch = 0; // Тангаж вверх или вних
  float yaw = 0;   // Поворот по часовой мом против часовой

  Struct_RPY &operator=(const Struct_RPY &source) // Специальный оператор, как функция в структуре, позволяет копировать одинаковые структуры просто знаком равно
  {
    roll = source.roll;
    pitch = source.pitch;
    yaw = source.yaw;
    return *this;
  }
};
//Структура для температурного датчика BMP280
struct Struct_BME
{
  float temperature = 0;
  float pressure = 0;
  float humidity = 0;
  float loc = 0;
};
//Структура для датчика напряжения INA219
struct Struct_INA
{
  float voltage = 0;
  float current = 0;
  float capacity_percent = 0;
  float capacity_real = 0;
};
//Структура одометрии
struct Struct_Odom
{
  float x = 0;      // Координата по Х
  float y = 0;      // Координата по Y
  float th = 0;     // Направление носа
  float vel_x = 0;  // Линейная скорость движения робота по оси X
  float vel_y = 0;  // Линейная скорость движения робота по оси Y 
  float vel_th = 0; // Угловая скорость вращения робота
  
  Struct_Odom &operator=(const Struct_Odom &source) // Специальный оператор, как функция в структуре, позволяет копировать одинаковые структуры просто знаком равно
  {
    x = source.x;
    y = source.y;
    th = source.th;
    vel_x = source.vel_x;
    vel_y = source.vel_y;
    vel_th = source.vel_th;
    return *this;
  }
};

Struct_Odom g_odom_enc; // Одометрия по энкодерам
Struct_Odom g_odom_imu; // Одометрия по гироскопу и аксельрометру
float g_radius = 0;     // Радиус по которому движемся
//float g_napravl = 0;     // Направление поворота по часовой или против часовой
float g_speed = 0;     // Скорость с которой движемся



//Структура в которой все главные переменные которые передаюся на высокий уровень
struct Struct_Body
{
  uint32_t id = 0;            // id команды
  Struct_Odom odom_enc;       // Одометрия по энкодерам
  Struct_Odom odom_imu;       // Одометрия по гироскопу и аксельрометру
  float odom_L = 0;           // Пройденный путь левым колесом
  float odom_R = 0;           // Пройденный путь правым колесом
  float speed_L = 0;          // Скорость левого колеса
  float speed_R = 0;          // Скорость правого колеса
  float distance_lazer_L = 0; // Данные лазерного датчика
  float distance_lazer_R = 0; // Данные лазерного датчика
  float distance_uzi = 0;     // Данные ультразвукового датчика
  Struct_RPY bno055;          // Данные с датчика BNO055
  Struct_BME bme;             // Данные с датчика BME
  Struct_INA ina;             // Данные с датчика INA219
  float gaz_data = 0;         // Данные с первого датчика газа
  float lux = 0;              // Данные с дачика освещенности
  uint32_t cheksum = 0;       // Контрольная сумма данных в структуре
};

// Структура получаемых данных
struct Struct_Data2Body
{
  uint32_t id = 0;          // Номер команды по порядку
  int32_t command_body = 0; // Команда для выполнения
  float radius = 0;         // Радиус по которому нужно двигаться
  float speed = 0;          // Скорость которую нужно установить
  float motor_video_angle;  // Угол для шагового мотора камеры
  uint32_t cheksum = 0;     // Контрольная сумма данных в структуре
};

Struct_Data2Body Data2Body_receive;                           // Экземпляр структуры получаемых данных
const int size_structura_receive = sizeof(Data2Body_receive); // Размер структуры с данными которые получаем

Struct_Body Body_send;                                                                                                         //Тело робота. тут все переменные его характеризующие на низком уровне
const int size_structura_send = sizeof(Body_send);                                                                             // Размер структуры с данными которые передаем
const uint16_t max_size_stuct = (size_structura_receive < size_structura_send) ? size_structura_send : size_structura_receive; // Какая из структур больше


//Функция возвращает контрольную сумму структуры без последних 4 байтов
template <typename T>
uint32_t measureCheksum(const T &structura_)
{
  uint32_t ret = 0;
  unsigned char *adr_structura = (unsigned char *)(&structura_); // Запоминаем адрес начала структуры. Используем для побайтной передачи
  for (int i = 0; i < sizeof(structura_) - 4; i++)
  {
    ret += adr_structura[i]; // Побайтно складываем все байты структуры кроме последних 4 в которых переменная в которую запишем результат
  }
  return ret;
}

#define Addr_TCA9548A 0x70 // Адреc платы мультиплексора шины I2C
// Функция устанавляивающая нужное положение на мультиплексоре
void set_TCA9548A(uint8_t bus)
{
    if (bus > 7)
        return;
    Wire.beginTransmission(Addr_TCA9548A); // TCA9548A адрес 0x70  or 0x77
    Wire.write(1 << bus);                  // отправляем байт на выбранную шину
    Wire.endTransmission();
}

/*

//Структура точки
struct Struct_Point
{
  float x = 0;                                        // Координата по Х
  float y = 0;                                        // Координата по Y
  float z = 0;                                        // Координата по Z
  Struct_Point &operator=(const Struct_Point &source) // Специальный оператор, как функция в структуре, позволяет копировать одинаковые структуры просто знаком равно
  {
    x = source.x;
    y = source.y;
    z = source.z;
    return *this;
  }
};
//Структура вектора
struct Struct_Vector3
{
  float x = 0;                                            // Координата по Х
  float y = 0;                                            // Координата по Y
  float z = 0;                                            // Координата по Z
  Struct_Vector3 &operator=(const Struct_Vector3 &source) // Специальный оператор, как функция в структуре, позволяет копировать одинаковые структуры просто знаком равно
  {
    x = source.x;
    y = source.y;
    z = source.z;
    return *this;
  }
};
//Структура ориентации
struct Struct_Quaternion
{
  float x = 0;                                                  // Координата по Х
  float y = 0;                                                  // Координата по Y
  float z = 0;                                                  // Координата по Z
  float w = 0;                                                  // Координата по W
  Struct_Quaternion &operator=(const Struct_Quaternion &source) // Специальный оператор, как функция в структуре, позволяет копировать одинаковые структуры просто знаком равно
  {
    x = source.x;
    y = source.y;
    z = source.z;
    w = source.w;
    return *this;
  }
};
//Структура позиции
struct Struct_Pose
{
  Struct_Point position;         //  Позиция
  Struct_Quaternion orientation; // Ориентация в позиции
};
//Структура движения
struct Struct_Twist
{
  Struct_Vector3 linear;  //  Позиция
  Struct_Vector3 angular; // Ориентация в позиции
};

//Структура движения
struct Struct_Odometry
{
  String child_frame_id = "base_link"; //  СИстема координат
  Struct_Pose pose;                    // позиция
  Struct_Twist twist;                  // движение
};
*/

#endif