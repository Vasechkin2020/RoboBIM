
#define MOTOR yes
#define MOTOR_VIDEO yes
#define BNO_def yes
#define VL530L0X_def yes
#define BME680_def yes
#define RCWL1601_def yes
#define INA219_def yes // Датчик по питанию
#define BH1750_def yes // Датчик освещенности

#include <Arduino.h>
#include <Wire.h>

#include <Preferences.h> // Для сохранения значений во внутренней флеш памяти
Preferences preferences; // Создаем экземпляр для сохрания настроек и работы с флеш памятью

#include <EEPROM.h>
// define the number of bytes you want to access
#define EEPROM_SIZE 32

#include "VL53L0X.h" // Чужая библиотека polulu https://github.com/pololu/vl53l0x-arduino
VL53L0X Sensor_VL53L0X_L;
VL53L0X Sensor_VL53L0X_R;

#include "config.h"

#include <Power.h> // Мой класс унаследованный от Adafruit_INA219
Power Ina219(0x40);
portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED; // Переменная для разделения доступа к переменным из основного потока и прерываний

#include "i2c_my.h"
#include "my_wifi.h"
#include "uzi.h"
#include "motor.h"
#include "protokolSPI.h"
#include "bme.h"

#include "bno.h"
#include "bh.h" // Датчик освещенности
//#include "boshsec.h"

#include "code.h"

void setup()
{
    delay(2000);
    initLed(); // Начальная инициализация и настройка светодиодов
    pinMode(PIN_ANALIZ, OUTPUT);

    Serial.begin(115200);
    Serial.println(" ");
    Serial.println(String(micros()) + " Start program ESP32_Body ...");

    // initialize EEPROM with predefined size
    EEPROM.begin(EEPROM_SIZE);

    Wire.begin(); // Старт шины I2C
    Wire.setClock(400000);
    //scanI2C();

    for (uint8_t i = 0; i < 8; i++)
    {
        set_TCA9548A(i);
        Serial.print("---");
        Serial.print(" Slot = ");
        Serial.println(i);
        scanI2C();
    }
    delay(1000);

#ifdef MOTOR
    initMotor(); // Начальная инициализация и настройка шаговых моторов
    setSpeed_L(0.5);
    setSpeed_R(0.5);
    delay(5000);
    stopMotor();
#endif

    // delay(99999999);

#ifdef BME_def
    Init_BME280();
#endif
#ifdef BME680_def
    Serial.println(F("initBME680 start... "));
    set_TCA9548A(1); //Переключаем мультиплексор
    initBME680();
    //initBoshSecBME680();
    //delay(999999);
#endif
#ifdef BNO_def
    Setup_BNO055();
#endif
#ifdef RCWL1601_def
    //Инициализация портов для ультразвукового датчика
    init_Uzi();
#endif

#ifdef VL530L0X_def
    printf("initInit_VL53L0X_L \n");
    Init_VL53L0X(Sensor_VL53L0X_L, multi_line_VL53L0X_L); // Инициализация датчиков сверху
    printf("initInit_VL53L0X_R \n");
    Init_VL53L0X(Sensor_VL53L0X_R, multi_line_VL53L0X_R); // Инициализация датчиков сверху
#endif
    //delay(999999);

    //init_WiFi(); //Инициализация Вайфай в нужных режимах

    printf("initTimer_0 \n");
    initTimer_0(); // Запуск таймера 0

    printf("initSPI_slave \n");
    initSPI_slave(); // Инициализация SPI_slave
    printf("spi_slave_queue_Send \n");
    spi_slave_queue_Send(); // Configure receiver Первый раз закладываем данные чтобы как только мастер к нам обратиться было чем ответить

#ifdef INA219_def
    init_INA219(); // Инициализация датчика тока
    //delay(3000);
#endif

    //useCore0();    // Использование 0 ядра
    //initPWM(); //Инициализация инастройка ШИМ на нужных пинах и канаах
    //taskCreateMotorVideo(); // Создание задачи для управления мотором видеокамеры

#ifdef MOTOR_VIDEO

    initServoMotor();                  // Инициализация пинов серво мотора
    setServoMotorVideoStartPosition(); //Установка в начальное положение которое становится нулем градусов
    // setServoMotorVideoAngle(100);  // Установка в нужное число градусов
    // delay(20000);
#endif

#ifdef BH1750_def
    init_BH1750();
#endif

    //delay(50000000);

    offLed(); // Отключение светодиодов

    delay(1000);
}

//portENTER_CRITICAL(&mux);
//interruptCounter--;
//portEXIT_CRITICAL(&mux);

/*
HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13); // Инвертирование состояния выхода.
HAL_Delay(50);                          // Пауза 500 миллисекунд.
printf("dkjfkdjfk %i", 125);
*/

int a, b;

void loop()
{
    // printf("+\n");
    digitalWrite(PIN_ANALIZ, 1);
    Led_Blink(PIN_LED_BLUE, 1000); // Мигаем светодиодом каждую секунду, что-бы было видно что цикл не завис

#ifdef RCWL1601_def
    loopUzi(); //Все действия по ультразвуковому датчику
#endif

    //----------------------------- 10 миллисекунд --------------------------------------
    if (flag_timer_10millisec)
    {
        flag_timer_10millisec = false;

#ifdef RCWL1601_def
        inTimerUzi(); // Проверка на случай если сигнал не вернется тогда через заданное время сбросим
#endif

        movementTime(); // Отслеживание времени движения
        delayMotor();   // Задержка отключения драйверов моторов после остановки
        //flag_data = true; // Зависает esp32 если включить при подключенной малинке
    }

    //----------------------------- По факту обмена данными с верхним уровнем --------------------------------------
    if (flag_data) // Если обменялись данными
    {
        flag_data = false;
        // printf("+\n");
        processing_Data(); // Обработка пришедших данных после состоявшегося обмена
        executeCommand();  // Выполнение пришедших команд

#ifdef INA219_def
        Ina219.calculate(); // Расчет емкости
#endif
#ifdef BNO_def
        BNO055_readEuler();  //Опрашиваем датчик получаем углы
        BNO055_readLinear(); //Опрашиваем датчик получаем ускорения
#endif

        // printf(" Receive id= %i cheksum= %i All obmen= %i bed_time= %i bed_crc= %i", Data2Body_receive.id, Data2Body_receive.cheksum, obmen_all, obmen_bed_time, obmen_bed_crc);
        // printf(" command= %i radius= %f speed= %f motor_video_angle= %f \n", Data2Body_receive.command_body, Data2Body_receive.radius, Data2Body_receive.speed, Data2Body_receive.motor_video_angle);
        // printf(" \n");

        //----------------------------- 50 миллисекунд --------------------------------------
        if (flag_timer_50millisec)
        {
            flag_timer_50millisec = false;
            // if (angle_pov_sum <= 90)
            // {
            // setSpeed_time(0.2, 0.2, 1000);
            // }

#ifdef VL530L0X_def
            loop_VL53L0X(); // Измерение лазерными датчиками
#endif
#ifdef RCWL1601_def
            if (!Flag_uzi_wait) // Если прошлый сигнал обработали и не ждем данные
            {
                Triger_start(); // Запускаем новый цикл измерения ультразвуковым датчиком каждые 50 милисекунд
            }
#endif
#ifdef BH1750_def
            // long a = micros();
            readBH1750(); // Чтение значения датчика освещенности примерно 250 микросекунд
                          // long b = micros();
                          // Serial.print(" time BH1750_def micros= ");
                          // Serial.println(b - a);
#endif
#ifdef BME680_def
            // a = micros();
            readBME680(); // Начинаем новый опрос датчика примерно 1700 микросекунд когда есть данные
                          // b = micros();
                          // Serial.print(" time BME680_def micros= ");
                          // Serial.println(b - a);
#endif
            gaz_volt = getVoltAnalogPin(PIN_GAZ) - 0.2; // Считывание напряжения на датчике газа, немного отнимаеи так как микроконтроллер у 0 не правильно считает, читай инет
        }

        calculateOdom_enc();    // Подсчет одометрии по энкодерам
        calculateOdom_imu();    // Подсчет одометрии по imu
        collect_Data();         // Собираем данные в структуре для отправки
        spi_slave_queue_Send(); // Закладываем данные в буфер для передачи(обмена)
    }
    //----------------------------- 1 секунда --------------------------------------
    if (flag_timer_1sec) // Вызывается каждую секунду
    {
        flag_timer_1sec = false;
        //printf(" %f \n", millis() / 1000.0);
        // printBH1750();
        // printBME680(); // Выводим на печать данные от датчика
        //Print_BME280();
        //Ina219.printData(); // Вывод на печать данных
        //printf(".");

        // long a = micros();
        // long b = micros();

        // Serial.print(b - a);
        // Serial.println(" time");

        // Serial.print(".");
        // printBody();

        // set_TCA9548A(1); //Переключаем мультиплексор
        // //readBosh();
        // Serial.print(" DT = ");
        // Serial.println(b-a);

        //Serial.println("setSpeed_time");

        // //float dist_laz = Read_VL53L0X() / 1000.0; // Превобразуем в метры
        // float dist_laz = Read_VL53L0X() ; // Превобразуем в метры

        // Serial.print(" distance_Lazer = ");
        // Serial.print(dist_laz);

        // Serial.print(" 35 pin=");
        // Serial.print(getVoltAnalogPin(35));
        // Serial.print(" Volt");
        // Serial.print(" 36 pin=");
        // Serial.print(getVoltAnalogPin(34));
        // Serial.print(" Volt");
        // Serial.println("");

        //printf(" + \n");
        // Serial.print(" TIME DATCHIK = ");
        // Serial.println(b - a);
    }

    if (flag_timer_60sec) // Вызывается каждую МИНУТУ
    {
        flag_timer_60sec = false;
#ifdef INA219_def
        //Ina219.calculateCapacity(); // колибровка в ноль и сохранение в память
#endif

        // Печать времени что программа не зависла, закомментировать в реальной работе
        printf(" %f \n", millis() / 1000.0);
    }
    digitalWrite(PIN_ANALIZ, 0);
}

//***********************************************************************
