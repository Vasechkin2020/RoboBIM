#ifndef BH_H
#define BH_H

#define multi_line_BH1750 2 // На какой линии мультиплексора находится датчик BH1750

#include <BH1750.h>
BH1750 lightMeter;
float g_lux = 0; // Значение датчика освещенности

void set_TCA9548A(uint8_t bus);  // Функция для мультплексора. Тело функции в main, а тут чисто для компилятора, чтобы не ругался.

void init_BH1750()
{
    Serial.print("init_BH1750... ");
    set_TCA9548A(multi_line_BH1750); //Переключаем мультиплексор
    lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE);
    Serial.println(" end. ");
    Serial.println("--- ");
}
void readBH1750()
{
    set_TCA9548A(multi_line_BH1750); //Переключаем мультиплексор
    g_lux = lightMeter.readLightLevel();
}

void printBH1750()
{
    Serial.print("Light: ");
    Serial.print(g_lux);
    Serial.println(" lx ");

}

#endif