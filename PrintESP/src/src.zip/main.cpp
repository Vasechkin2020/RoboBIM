
#include <Arduino.h>
#include <Wire.h>

#include <Preferences.h> // Для сохранения значений во внутренней флеш памяти
Preferences preferences; // Создаем экземпляр для сохрания настроек и работы с флеш памятью

#include "my_wifi.h"
#include "config.h"
#include "code.h"
#include "protokolSPI.h"

// #ifdef MOTOR
// #include "motor.h"
// #endif

// // Задача для нулевого ядра
// TaskHandle_t TaskCore0;

// void loop_0_core(void *pvParameters)
// {
//     for (;;) // Бесконечный цикл. По while(1) не работает из-за сторожевого таймера
//     {
//         // digitalWrite(led1, HIGH);
//         // delay(1000);
//         // digitalWrite(led1, LOW);
//         // delay(1000);
//         // Serial.print("Task0code running on core = ");
//         // Serial.println(xPortGetCoreID());
//     }
//     //vTaskDelete(TaskCore0); // Удаление ранее созданной задачи
// }
// // Создаем задачу с кодом из функции Task1code(), с приоритетом 1 и выполняемую на ядре 0:
// void useCore0()
// {
//     xTaskCreatePinnedToCore(
//         loop_0_core, /* Функция задачи */
//         "TaskCore0", /* Название задачи */
//         10000,       /* Размер стека задачи */
//         NULL,        /* Параметр задачи */
//         1,           /* Приоритет задачи */
//         &TaskCore0,  /* Идентификатор задачи, чтобы ее можно было отслеживать */
//         0);          /* Ядро для выполнения задачи (0) */
//     delay(500);
// }

void setup()
{

    Serial.begin(115200);
    Serial.println(" ");
    Serial.println(String(micros()) + "Start program ...");

    initLed(); // Начальная инициализация и настройка светодиодов

    // initMotor(); // Начальная инициализация и настройка шаговых моторов
    // setSpeed_L(0.5);
    // setSpeed_R(0.5);
    // delay(5000);
    // stopMotor();

    Wire.begin(); // Старт шины I2C
    scanI2C();

    // // while (1)
    // // {
    // //     Serial.println(String(micros()) + "...");
    // //     scanI2C();
    // //     delay(500);
    // // }

    // init_WiFi(); //Инициализация Вайфай в нужных режимах
    // testPing();  // Проверка пингом внешнего интернета

    initTimer_0(); // Запуск таймера 0

    initSPI_slave();        // Инициализация SPI_slave
    spi_slave_queue_Send(); // Configure receiver Первый раз закладываем данные чтобы как только мастер к нам обратиться было чем ответить

    printf("Заложили данные \n");
    
    
    //useCore0();    // Использование 0 ядра
    //initPWM(); //Инициализация инастройка ШИМ на нужных пинах и канаах

    // taskCreateMotorVideo(); // Создание задачи для управления мотором видеокамеры

    // stepTarget  = getStepFrom_Angle(-120);
    // delay(5000);
    // Serial.print("stepTarget>");    Serial.println(stepTarget);
    // Serial.print("stepFact>");    Serial.println(stepFact);
    // stepFact = 0;
    // stepTarget  = getStepFrom_Angle(180);
    // delay(5000);
    // Serial.print("stepTarget>");    Serial.println(stepTarget);
    // Serial.print("stepFact>");    Serial.println(stepFact);
    // // stepTarget  = getStepFrom_Angle(3600);
    // // Serial.print("stepTarget>");    Serial.println(stepTarget);
    // delay(50000000);

    offLed(); // Отключение светодиодов
}

bool asdfdfdfsd_fsdfsdf = false;
void printMy()
{
    printf("=fgh sdfsdfsdfsdfsdfdsfsdfsdfsdfhg /+ %i \n",millis());
    if (asdfdfdfsd_fsdfsdf == false)
    {
         printf("=/+ %i \n",millis());
    }

}   
void loop()
{

    Led_Blink(PIN_LED_GREEN, 1000); // Мигаем светодиодом каждую секунду, что-бы было видно что цикл не завис

    if (flag_data) // Если обменялись данными
    {
        flag_data = false;
        processing_Data(); //Обработка пришедших данных после состоявшегося обмена
        executeCommand();  // Выполнение пришедших команд
        //calculateOdom();        // Подсчет одометрии
        collect_Data();         // Собираем данные в структуре для отправки
        spi_slave_queue_Send(); // Закладываем данные в буфер для передачи(обмена)

        printf(" All obmen= %i bed_time= %i bed_crc= %i", obmen_all, obmen_bed_time, obmen_bed_crc);
        printf(" \n");
    }

    if (flag_timer_10millisec)
    {
        flag_timer_10millisec = false;
        //movementTime();   // Отслеживание времени движения
        printf(".");
    }
    if (flag_timer_1sec) // Вызывается каждую секунду
    {
        flag_timer_1sec = false;
        //delayMotor(); // Задержка отключения драйверов моторов после остановки

        printMy();
    }

    if (flag_timer_60sec) // Вызывается каждую МИНУТУ
    {
        flag_timer_60sec = false;
    }
}

//***********************************************************************
