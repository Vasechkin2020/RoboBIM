#ifndef CONFIG_H
#define CONFIG_H

#define MOTOR yes
// #define BNO055_def yes
//#define VL530L0X_def yes
// #define BME280_def yes
//#define RCWL1601_def yes

// Контакты для светодиодов:
const int PIN_LED_RED = 25;
const int PIN_LED_BLUE = 26;
const int PIN_LED_GREEN = 27;


volatile bool flag = false;
volatile bool flag_timer_1sec = false;
volatile bool flag_timer_10millisec = false;
volatile bool flag_timer_60sec = false;
volatile int count_timer_10millisec = 0; //Счетчик для запуска обработки движения моторов в лупе по флагу
volatile int count_timer_1sec = 0;       // Счетчик для запуска
volatile int count_timer_60sec = 0;      // Счетчик для запуска

hw_timer_t *timer0 = NULL;
hw_timer_t *timer1 = NULL;
hw_timer_t *timer2 = NULL;

//Функция исполняемая по прерыванию по таймеру 0
void IRAM_ATTR onTimer() // Обработчик прерывания таймера 0 по совпадению A 	1 раз в 1 милисекунду
{
  //portENTER_CRITICAL_ISR(&timerMux);
  //interruptCounter++;
  //portEXIT_CRITICAL_ISR(&timerMux);

  count_timer_10millisec++;
  count_timer_1sec++;
  count_timer_60sec++;

  // 50 milliseconds
  if (count_timer_1sec >= 1000)
  {
    count_timer_1sec = 0;
    flag_timer_1sec = true;
  }
  // Расчет потребляемой энергии или заряда, каждые 10 милисекунд
  if (count_timer_10millisec >= 10)
  {
    count_timer_10millisec = 0;
    flag_timer_10millisec = true;
  }
  // Таймер на 1 секунду
  if (count_timer_60sec >= 60000)
  {
    count_timer_60sec = 0;
    flag_timer_60sec = true;
  }

  flag = true;
}

//Инициализация таймера 0. Всего 4 таймера вроде от 0 до 3 //https://techtutorialsx.com/2017/10/07/esp32-arduino-timer-interrupts/
void initTimer_0()
{
  timer0 = timerBegin(0, 80, true);             // Номер таймера, делитель(прескаллер), Считать вверх, прибавлять (true)  Частота базового сигнала 80  Мега герц, значит будет 1 микросекунда
  timerAttachInterrupt(timer0, &onTimer, true); // Какой таймер используем, какую функцию вызываем,  тип прерывания  edge или level interrupts
  timerAlarmWrite(timer0, 1000, true);          // Какой таймер, до скольки считаем , сбрасываем ли счетчик при срабатывании 1000 микросекунд эти 1 милисекунда
  timerAlarmEnable(timer0);                     // Запускаем таймер
}

//*********************************************************************
//Структура для углов Эллера
struct Struct_XYZ
{
  float x = 0;
  float y = 0;
  float z = 0;

  Struct_XYZ &operator=(const Struct_XYZ &source) // Специальный оператор, как функция в структуре, позволяет копировать одинаковые структуры просто знаком равно
  {
    x = source.x;
    y = source.y;
    z = source.z;
    return *this;
  }
};
//Структура для температурного датчика BMP280
struct Struct_BME
{
  float temperature = 0;
  float pressure = 0;
  float humidity = 0;
  float loc = 0;
};

//Структура в которой все главные переменные которые передаюся на высокий уровень
struct Struct_Body
{
  uint32_t id = 0;            // id команды
  float odom_L = 0;           // Пройденный телом путь
  float odom_R = 0;           // Пройденный телом путь
  float speed_L = 0;          // Скорость левого колеса
  float speed_R = 0;          // Скорость правого колеса	// float distance_uzi = 0;		 // Данные ультразвукового датчика
  float distance_lazer_L = 0; // Данные лазерного датчика
  float distance_lazer_R = 0; // Данные лазерного датчика
  float distance_uzi = 0;     // Данные ультразвукового датчика
  Struct_XYZ bno055;          // Данные с датчика BNO055
  Struct_BME bme;             // Данные с датчика BME
  float gaz_data = 0;         // Данные с первого датчика газа
  uint32_t cheksum = 0;       // Контрольная сумма данных в структуре
};

// Структура отправляемых данных
struct Struct_Data2Body
{
  uint32_t id = 0;         // Номер команды по порядку
  int32_t command_body = 0;     // Команда для выполнения
  float radius = 0;        // Радиус по которому нужно двигаться
  float speed = 0;         // Скорость которую нужно установить
  float motor_video_angle; // Угол для шагового мотора камеры
  uint32_t cheksum = 0;    // Контрольная сумма данных в структуре
};

Struct_Data2Body Data2Body_receive;                        // Экземпляр структуры получаемых данных
const int size_structura_receive = sizeof(Data2Body_receive); // Размер структуры с данными которые получаем

Struct_Body Body_send;                                                                                                   //Тело робота. тут все переменные его характеризующие на низком уровне
const int size_structura_send = sizeof(Body_send);                                                                          // Размер структуры с данными которые передаем
const uint16_t max_size_stuct = (size_structura_receive < size_structura_send) ? size_structura_send : size_structura_receive; // Какая из структур больше


#endif