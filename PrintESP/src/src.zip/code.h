#ifndef CODE_H
#define CODE_H

void initLed()
{
  pinMode(PIN_LED_RED, OUTPUT);
  pinMode(PIN_LED_BLUE, OUTPUT);
  pinMode(PIN_LED_GREEN, OUTPUT);

  digitalWrite(PIN_LED_RED, 1);   // Запустился SetUp
  digitalWrite(PIN_LED_BLUE, 1);  // Запустился SetUp
  digitalWrite(PIN_LED_GREEN, 1); // Запустился SetUp
}

void offLed()
{
  digitalWrite(PIN_LED_RED, 0);   // Запустился SetUp
  digitalWrite(PIN_LED_BLUE, 0);  // Запустился SetUp
  digitalWrite(PIN_LED_GREEN, 0); // Запустился SetUp
}
//Функция мигания светодиодом в основном цикле
void Led_Blink(int led_, unsigned long time_)
{
  static unsigned long led_time = 0;
  static bool led_status = 0;
  if ((millis() - led_time) > time_)
  {
    led_status = 1 - led_status;
    digitalWrite(led_, led_status);
    // digitalWrite(PIN_POWER_OFF, 1); // Выключение питания
    // delay(50);
    // digitalWrite(PIN_POWER_OFF, 0); // Выключение питания
    led_time = millis();
  }
}

// Функция сканирования I2C устройств
void scanI2C()
{
  byte error, address;
  int nDevices;

  Serial.println("Scanning...");

  nDevices = 0;
  for (address = 8; address < 127; address++)
  {
    Wire.beginTransmission(address);
    error = Wire.endTransmission();

    if (error == 0)
    {
      Serial.print("I2C device found at address 0x");
      if (address < 16)
        Serial.print("0");
      Serial.print(address, HEX);
      Serial.println(" !");

      nDevices++;
    }
    else if (error == 4)
    {
      Serial.print("Unknow error at address 0x");
      if (address < 16)
        Serial.print("0");
      Serial.println(address, HEX);
    }
  }
  if (nDevices == 0)
    Serial.println("No I2C devices found\n");
  else
    Serial.println("done\n");
}

// задаем свойства ШИМ-сигнала:
const int freq = 5000;
const int ledChannel = 0;
const int resolution = 8; // 8 бит от 0 до 255,  10 бит от 0 до 1024

void initPWM()
{
  // // настраиваем ШИМ-сигнал, используя свойства выше:
  // ledcSetup(ledChannel, freq, resolution);
  // // привязываем ШИМ канал к GPIO-контакту, которым будем управлять:
  // ledcAttachPin(led2, ledChannel);
}

//Управление ярокстью светодиода меняя ШИМ
void ledPWM()
{
  // увеличиваем яркость светодиода:
  for (int dutyCycle = 0; dutyCycle <= 255; dutyCycle++)
  {
    // меняем яркость светодиода при помощи ШИМ:
    ledcWrite(ledChannel, dutyCycle);
    delay(15);
  }

  // уменьшаем яркость светодиода:
  for (int dutyCycle = 255; dutyCycle >= 0; dutyCycle--)
  {
    // меняем яркость светодиода при помощи ШИМ:
    ledcWrite(ledChannel, dutyCycle);
    delay(15);
  }
}

//Функция возвращает контрольную сумму структуры без последних 4 байтов
template <typename T>
uint32_t measureCheksum(const T &structura_)
{
  uint32_t ret = 0;
  unsigned char *adr_structura = (unsigned char *)(&structura_); // Запоминаем адрес начала структуры. Используем для побайтной передачи
  for (int i = 0; i < sizeof(structura_) - 4; i++)
  {
    ret += adr_structura[i]; // Побайтно складываем все байты структуры кроме последних 4 в которых переменная в которую запишем результат
  }
  return ret;
}

// Собираем нужные данные и пишем в структуру на отправку
void collect_Data()
{
  Body_send.id++;
  Body_send.odom_L = 3.14;
  Body_send.odom_R = 3.15;
  Body_send.speed_L = 3.16;
  Body_send.speed_R = 3.17;
  Body_send.distance_lazer_L = 3.19;
  Body_send.distance_lazer_R = 3.19;
  Body_send.distance_uzi = 3.20;
  Body_send.bno055.x = 3.21;
  Body_send.bno055.y = 3.22;
  Body_send.bno055.z = 3.23;
  Body_send.bme.temperature = 3.24;
  Body_send.bme.pressure = 3.25;
  Body_send.bme.humidity = 3.26;
  Body_send.bme.loc = 3.27;
  Body_send.gaz_data = 3.28;

  Body_send.cheksum = measureCheksum(Body_send); // Вычисляем контрольную сумму структуры и пишем ее значение в последний элемент

  printf(" / Send id= %i", Body_send.id);
  printf(" Send cheksum= %i   /   ", Body_send.cheksum);
}

// Отработка пришедших команд. Изменение скорости, траектории и прочее
void executeCommand()
{
  // if (DataHL.command == 0)
  // {
  // 	//Serial.println("commanda  STOP...");
  // 	stopMotor(); //все остановливаем
  // }
  // if (DataHL.command == 1)
  // {
  // 	int direction;
  // 	if (DataHL.radius == 0 ) direction = 0;
  // 	if (DataHL.radius > 0 ) direction = 1;
  // 	if (DataHL.radius < 0 ) direction = -1;
  // 	setSpeed_time(DataHL.speed, abs(DataHL.radius), direction, 1000);
  // }
}

#endif