#include <geometry_msgs/Twist.h>
#include <ros/ros.h>
#include <sensor_msgs/Joy.h>
#include <std_srvs/Trigger.h>

#define LOOP_RATE 100

/* * * BUTTONS * * * * * * * * * *
0 - X
1 - O
2 - triangle
3 - square
4 - L1
5 - R1
* * * Arrows in "axes" array * * *
left - axes[6] = 1
right - axes[6] = -1
down - axes[7] = -1
up - axes[7] = 1
 * * * * * * * * * * * * * * * * */

/* * * AXES (JOYSTICKS) * * *
 *                    left (down) / neutral / right (up)
0 - Left Horizontal           1.0 /       0 / -1.0
1 - Left Vertical            -1.0 /       0 /  1.0
2 - L2                       -1.0 /     1.0 /  1.0
3 - Right Horizontal          1.0 /     0.0 / -1.0
4 - Right Vertical           -1.0 /     0.0 /  1.0
5 - R2                       -1.0 /     1.0 /  1.0
 * * * * * * * * * * * * * * */

#define MAX_LIN_VEL 0.2
#define MAX_ANG_VEL 0.8

static sensor_msgs::Joy joy;
static ros::Publisher pub_cmd_vel;
static ros::Subscriber sub_joy;

// static bool is_joy_updated;
// static bool is_emergency_stop;
// static bool is_safety_trigger;

// static ros::ServiceClient hard_stop;
// static ros::ServiceClient disable_hard_stop;
static ros::ServiceClient srv_restart_sim;
static ros::ServiceClient srv_do_step;

//set 0 value to all arrays
void init()
{
  // for(uint8_t i = 0; i < MAX_NUMBER_OF_ROBOTS; i++)
  // {
  //   is_joy_updated[i] = false;
  //   is_emergency_stop[i] = false;
  //   is_safety_trigger[i] = false;
  // }
}

//adjustable delay timer
void delayTimer(uint16_t dt)
{
  ros::Rate timer_rate(1000);
  uint32_t timer = 0;

  while (timer < dt)
  {
    timer_rate.sleep();
    timer++;
  }
}

void joyCallback(sensor_msgs::Joy msg)
{
  joy = msg;

  // //press triangle - hard stop
  // if(joy.buttons[2] == 1 && joy.buttons[4] == 0 && joy.buttons[5] == 0 && is_emergency_stop[robot_number] == false)
  // {
  //   std_srvs::Trigger srv;

  //   if(hard_stop[robot_number].call(srv))
  //   {
  //     ROS_WARN("Kursant %d: HARD STOP!", robot_number+1);
  //   }
  //   else
  //   {
  //     ROS_ERROR("Kursant %d: Can't call hard stop service!", robot_number+1);
  //   }

  //press triangle - restart sim
  if(joy.buttons[2] == 1)
  {
    std_srvs::Trigger srv;

    if(srv_restart_sim.call(srv))
    {
      ROS_WARN_STREAM("Restart simulation");
    }
    else
    {
      ROS_ERROR_STREAM("Restart sim FAILED!");
    }
  }

  if(joy.buttons[3] == 1)
  {
    std_srvs::Trigger srv;

    if(srv_do_step.call(srv))
    {
      ROS_WARN_STREAM("Service call succeeded!");
    }
    else
    {
      ROS_ERROR_STREAM("Service call failed!");
    }
  }

  //   is_emergency_stop[robot_number] = true;
  // }
  // //press L1+R1+triangle - disable hard stop
  // else if(joy.buttons[2] == 1 && joy.buttons[4] == 1 && joy.buttons[5] == 1 && is_emergency_stop[robot_number] == true)
  // {
  //   is_emergency_stop[robot_number] = false;

  //   std_srvs::Trigger srv;

  //   if(disable_hard_stop[robot_number].call(srv))
  //   {
  //     ROS_WARN("Kursant %d: HARD STOP DISABLED!", robot_number+1);
  //   }
  //   else
  //   {
  //     ROS_ERROR("Kursant %d: Can't call disable hard stop service!", robot_number+1);
  //   }
  // }
  // else if(joy.axes[5] < -0.8)
  // {
  //   is_safety_trigger[robot_number] = true;
  //   is_joy_updated[robot_number] = true;
  // }

  // if(joy.axes[5] > -0.8 && is_safety_trigger[robot_number] == true)
  // {
  //   is_safety_trigger[robot_number] = false;

  //   ROS_INFO("Kursant %d: Safety stop", robot_number+1);

  //   geometry_msgs::Twist msg;

  //   msg.linear.x = 0;

  //   msg.angular.z = 0;

  //   delayTimer(150);

  //   cmd_vel[robot_number].publish(msg);

  //   delayTimer(150);
  // }

  geometry_msgs::Twist cmd;

  cmd.linear.x = joy.axes[1];  //left vertical axis
  cmd.linear.y = joy.axes[0];  //left horizontal axis
  cmd.angular.z = joy.axes[3]; //right horizontal axis
  cmd.angular.x = joy.axes[4]; //right vertical axis

  pub_cmd_vel.publish(cmd);
}

//convert speed form meters to mm, round and convert back to meters
float speedStepControl(float vel_m)
{
  int16_t vel_cm = 0;

  vel_cm = vel_m * 100;

  return float(vel_cm) / 100;
}

void move()
{
  //   if(is_joy_updated[robot_number] == true && is_safety_trigger[robot_number] == true)
  //   {
  //     geometry_msgs::Twist msg;

  // //    msg.linear.x = joy.axes[4] * MAX_LIN_VEL;
  // //    msg.angular.z = joy.axes[3] * MAX_ANG_VEL;

  //     msg.linear.x = speedStepControl(joy.axes[4] * MAX_LIN_VEL);
  //     msg.angular.z = speedStepControl(joy.axes[3] * MAX_ANG_VEL);

  //     cmd_vel[robot_number].publish(msg);

  //     is_joy_updated[robot_number] = false;
  //   }
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "gamepad_control");
  ros::NodeHandle n;
  ros::Rate rate(LOOP_RATE);

  ROS_INFO("Initialization...");

  sub_joy = n.subscribe("/joy", 1, joyCallback, ros::TransportHints().tcpNoDelay(true));

  pub_cmd_vel = n.advertise<geometry_msgs::Twist>("/cmd_vel", 1);

  srv_restart_sim = n.serviceClient<std_srvs::Trigger>("restart_sim");
  srv_do_step = n.serviceClient<std_srvs::Trigger>("/do_step");
  // hard_stop = n.serviceClient<std_srvs::Trigger>("/hard_stop");
  // disable_hard_stop = n.serviceClient<std_srvs::Trigger>("/disable_hard_stop");

  ROS_INFO("Enter loop");
  while (ros::ok())
  {
    // if(is_emergency_stop == false)
    // {
    //   move();
    // }

    ros::spinOnce();
    rate.sleep();
  }

  return 0;
}
